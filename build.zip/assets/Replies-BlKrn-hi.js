import{j as m,C as a,s as e}from"./index-V5PAVy6i.js";const n=({replyIds:s})=>s==null?void 0:s.map(t=>m.jsx(a,{commentId:t,className:e.commentReply},t));export{n as default};
